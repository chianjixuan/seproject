﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for LecturerPage.xaml
    /// </summary>
    public partial class LecturerPage : Window
    {
        string lecturercode;
        public LecturerPage(string lecturer)
        {
            lecturercode = lecturer;
            InitializeComponent();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            LecturerPasswordChange LecturerPasswordChange1 = new LecturerPasswordChange(lecturercode);
            this.Close();
            LecturerPasswordChange1.Show();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            ClassSession ClassSession1 = new ClassSession(lecturercode);
            this.Close();
            ClassSession1.Show();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            LecturerTimetable LecturerTimetable1 = new LecturerTimetable(lecturercode);
            this.Close();
            LecturerTimetable1.Show();
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            AttendanceRecord AttendanceRecord1 = new AttendanceRecord(lecturercode);
            this.Close();
            AttendanceRecord1.Show();
        }
    }
}
