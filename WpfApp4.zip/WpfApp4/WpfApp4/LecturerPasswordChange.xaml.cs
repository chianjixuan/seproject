﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for LecturerPasswordChange.xaml
    /// </summary>
    public partial class LecturerPasswordChange : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd,lecturercode;
        public LecturerPasswordChange(String lecturer)
        {
            lecturercode = lecturer;
            InitializeComponent();
        }

        private void LecturerPasswordChangeclosing(object sender, CancelEventArgs e)
        {
            LecturerPage LecturerPage1 = new LecturerPage(lecturercode);
            //this.Close();
            LecturerPage1.Show();
        }


        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                cmd = "UPDATE User1 SET Password='" + textBox1.Password + "' WHERE UserID='" + lecturercode + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Modify!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
