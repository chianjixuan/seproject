﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Window3 win3 = new Window3();
            this.Close();
            win3.Show();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            TimeTable TimeTable1 = new TimeTable();
            this.Close();
            TimeTable1.Show();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            StudentInformation StudentInformation1 = new StudentInformation();
            this.Close();
            StudentInformation1.Show();
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            Subject Subject1 = new Subject();
            this.Close();
            Subject1.ShowDialog();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Enrollment Enrollment1 = new Enrollment();
            this.Close();
            Enrollment1.ShowDialog();
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            AdminAttendanceRecord AdminAttendanceRecord1 = new AdminAttendanceRecord();
            this.Close();
            AdminAttendanceRecord1.ShowDialog();
        }
    }
}
