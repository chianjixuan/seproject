﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Threading;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for StudentInformation.xaml
    /// </summary>
    public partial class StudentInformation : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd;
        int retCode;
        int hCard;
        int hContext;
        int Protocol;
        public bool connActive = false;
        string readername = "ACR ACR122u 0";      // change depending on reader
        public byte[] SendBuff = new byte[263];
        public byte[] RecvBuff = new byte[263];
        public int SendLen, RecvLen, nBytesRet, reqType, Aprotocol, dwProtocol, cbPciLength;


        public Card.SCARD_READERSTATE RdrState;
        public Card.SCARD_IO_REQUEST pioSendRequest;


        public StudentInformation()
        {
            InitializeComponent();
        }
        private void studentinformationloaded(object sender, RoutedEventArgs e)
        {
            getgrid();
            SelectDevice();
            establishContext();
            //Thread.Sleep(1000);
            //Task task = Task.Run((Action)ThreadTask);

        }

        private void studentinformationclosing(object sender, CancelEventArgs e)
        {
            Window2 win2 = new Window2();
            //this.Close();
            win2.Show();
        }


        private void cardscanned()
        {
            
            Application.Current.Dispatcher.Invoke(new Action(delegate
            {
               
                if (connectCard())
                {
                    string cardUID = getcardUID();
                    textBoxCardID.Text = cardUID; //displaying on text block
                }
                else
                {
                    SelectDevice();
                    establishContext();
                }
                
            }));
        }

        private void getgrid()
        {
            try
            {

                cmd = "select * from StudentInformation";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        public void SelectDevice()
        {
            List<string> availableReaders = this.ListReaders();
            this.RdrState = new Card.SCARD_READERSTATE();
            readername = availableReaders[0].ToString();//selecting first device
            this.RdrState.RdrName = readername;
        }

        public List<string> ListReaders()
        {
            int ReaderCount = 0;
            List<string> AvailableReaderList = new List<string>();

            //Make sure a context has been established before 
            //retrieving the list of smartcard readers.
            retCode = Card.SCardListReaders(hContext, null, null, ref ReaderCount);
            if (retCode != Card.SCARD_S_SUCCESS)
            {
                MessageBox.Show(Card.GetScardErrMsg(retCode));
                //connActive = false;
            }

            byte[] ReadersList = new byte[ReaderCount];

            //Get the list of reader present again but this time add sReaderGroup, retData as 2rd & 3rd parameter respectively.
            retCode = Card.SCardListReaders(hContext, null, ReadersList, ref ReaderCount);
            if (retCode != Card.SCARD_S_SUCCESS)
            {
                MessageBox.Show(Card.GetScardErrMsg(retCode));
            }

            string rName = "";
            int indx = 0;
            if (ReaderCount > 0)
            {
                // Convert reader buffer to string
                while (ReadersList[indx] != 0)
                {

                    while (ReadersList[indx] != 0)
                    {
                        rName = rName + (char)ReadersList[indx];
                        indx = indx + 1;
                    }

                    //Add reader name to list
                    AvailableReaderList.Add(rName);
                    rName = "";
                    indx = indx + 1;

                }
            }
            return AvailableReaderList;

        }

        internal void establishContext()
        {
            retCode = Card.SCardEstablishContext(Card.SCARD_SCOPE_SYSTEM, 0, 0, ref hContext);
            if (retCode != Card.SCARD_S_SUCCESS)
            {
                MessageBox.Show("Check your device and please restart again", "Reader not connected", MessageBoxButton.OK, MessageBoxImage.Warning);
                connActive = false;
                return;
            }
        }

        public bool connectCard()
        {
            connActive = true;

            retCode = Card.SCardConnect(hContext, readername, Card.SCARD_SHARE_SHARED,
            Card.SCARD_PROTOCOL_T0 | Card.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != Card.SCARD_S_SUCCESS)
            {
                //MessageBox.Show(Card.GetScardErrMsg(retCode), "Card not available", MessageBoxButton.OK, MessageBoxImage.Error);
                connActive = false;
                return false;
            }
            return true;
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            Thread thread = new Thread(cardscanned);
            thread.Start();
        }

        private string getcardUID()//only for mifare 1k cards
        {
            string cardUID = "";
            byte[] receivedUID = new byte[256];
            Card.SCARD_IO_REQUEST request = new Card.SCARD_IO_REQUEST();
            request.dwProtocol = Card.SCARD_PROTOCOL_T1;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(Card.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command for Mifare cards
            int outBytes = receivedUID.Length;
            int status = Card.SCardTransmit(hCard, ref request, ref sendBytes[0], sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            if (status != Card.SCARD_S_SUCCESS)
            {
                cardUID = "Error";
            }
            else
            {
                cardUID = BitConverter.ToString(receivedUID.Take(4).ToArray()).Replace("-", string.Empty).ToLower();
            }

            return cardUID;
        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int User1;

            User1 = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(User1) as DataRowView;
            textBoxStudentID.Text = Row1["StudentID"].ToString().Trim();
            textBoxName.Text = Row1["StudentName"].ToString().Trim();
            textBoxIC.Text = Row1["IC"].ToString().Trim();
            textBoxYearEnroll.Text = Row1["YearEnroll"].ToString().Trim();
            textBoxCardID.Text = Row1["CardID"].ToString().Trim();

        }

        private void ClearText()
        {
            textBoxStudentID.Text = null;
            textBoxName.Text = null;
            textBoxIC.Text = null;
            textBoxYearEnroll.Text = null;
            textBoxCardID.Text = null;
            textBoxYearEnroll.Text = null;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                cmd = "INSERT INTO StudentInformation(StudentID, StudentName, IC, YearEnroll, CardID) Values('" + textBoxStudentID.Text + "','" + textBoxName.Text + "','" + textBoxIC.Text + "','" + textBoxYearEnroll.Text + "','"  + textBoxCardID.Text + "')";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Create!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Duplicate UserID");
            }


        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                cmd = "DELETE FROM StudentInformation WHERE StudentID='" + textBoxStudentID.Text + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Delete!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                cmd = "UPDATE StudentInformation SET StudentName ='" + textBoxName.Text + "',IC='" + textBoxIC.Text + "',YearEnroll='" + textBoxYearEnroll.Text + "',CardID='" + textBoxCardID.Text + "' WHERE StudentID='" + textBoxStudentID.Text + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Modify!");
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            textBoxStudentID.Text = null;
            textBoxName.Text = null;
            textBoxIC.Text = null;
            textBoxYearEnroll.Text = null;
            textBoxCardID.Text = null;
            textBoxYearEnroll.Text = null;
        }
    }
}
