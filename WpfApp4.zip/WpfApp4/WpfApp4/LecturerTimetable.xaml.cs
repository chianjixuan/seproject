﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for LecturerTimetable.xaml
    /// </summary>
    public partial class LecturerTimetable : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd, cmd1, lecturercode, MainID;
        public LecturerTimetable(string lecturer)
        {
            lecturercode = lecturer;
            InitializeComponent();
        }
        private void Lecturertimetableloaded(object sender, RoutedEventArgs e)
        {
            getgrid();
            getcomboboxdata();
        }

        private void Lecturertimetableclosing(object sender, CancelEventArgs e)
        {
            LecturerPage LecturerPage1 = new LecturerPage(lecturercode);
            LecturerPage1.Show();
        }

        private void getgrid()
        {
            try
            {

                cmd = "select * from TimeTableDtl WHERE LecturerID = '" + lecturercode + "'";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void getcomboboxdata()
        {
            ComboBox time1 = new ComboBox();
            try
            {
                comboBoxStartTime.Items.Add("09:00");
                comboBoxStartTime.Items.Add("10:00");
                comboBoxStartTime.Items.Add("11:00");
                comboBoxStartTime.Items.Add("12:00");
                comboBoxStartTime.Items.Add("13:00");
                comboBoxStartTime.Items.Add("14:00");
                comboBoxStartTime.Items.Add("15:00");
                comboBoxStartTime.Items.Add("16:00");
                comboBoxStartTime.Items.Add("17:00");
                comboBoxStartTime.Items.Add("18:00");

                comboBoxEndTime.Items.Add("09:00");
                comboBoxEndTime.Items.Add("10:00");
                comboBoxEndTime.Items.Add("11:00");
                comboBoxEndTime.Items.Add("12:00");
                comboBoxEndTime.Items.Add("13:00");
                comboBoxEndTime.Items.Add("14:00");
                comboBoxEndTime.Items.Add("15:00");
                comboBoxEndTime.Items.Add("16:00");
                comboBoxEndTime.Items.Add("17:00");
                comboBoxEndTime.Items.Add("18:00");

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }



        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int Timetable;

            Timetable = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(Timetable) as DataRowView;

            MainID = Row1["ID"].ToString().Trim();
            //MessageBox.Show(MainID);
            label9.Content = Row1["SubjectID"].ToString().Trim();
            //comboBoxLecturerID.Text = Row1["LecturerID"].ToString().Trim();
            datePicker.Text = Row1["Days"].ToString().Trim();
            comboBoxStartTime.Text = Row1["StartTime"].ToString().Trim();
            comboBoxEndTime.Text = Row1["EndTime"].ToString().Trim();

        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            string date1 = datePicker.SelectedDate.Value.ToString("yyyy-MM-dd");
            try
            {
                cmd = "UPDATE TimetableDtl SET Days ='" + date1 + "',StartTime='" + comboBoxStartTime.Text + "',Endtime='" + comboBoxEndTime.Text + "' WHERE ID = '" + MainID + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Modify!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ClearText()
        {
            datePicker.Text = null;
            comboBoxStartTime.Text = null;
            comboBoxEndTime.Text = null;
        }
    }
}
