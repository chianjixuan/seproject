﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for TimeTable.xaml
    /// </summary>
    public static class DateUtils
    {
        public static List<String> GetWeekdayInRange(this DateTime from, DateTime to, DayOfWeek day)
        {
            const int daysInWeek = 7;
            var result = new List<String>();
            var daysToAdd = ((int)day - (int)from.DayOfWeek + daysInWeek) % daysInWeek;
            
            do
            {
                from = from.AddDays(daysToAdd);
                result.Add(from.ToString("yyyy-MM-dd"));
                daysToAdd = daysInWeek;
            } while (from < to);
            return result;
        }
    }

    public partial class TimeTable : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd,cmd1, cmd2, MainID;
        public TimeTable()
        {
            InitializeComponent();
        }

        private void TimeTableloaded(object sender, RoutedEventArgs e)
        {
            getgrid();
            getcomboboxdata();
        }

        private void timetableclosing(object sender, CancelEventArgs e)
        {
            Window2 win2 = new Window2();
            win2.Show();
        }

        private void getgrid()
        {
            try
            {

                cmd = "select * from TimeTable";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void getcomboboxdata()
        {
            ComboBox time1 = new ComboBox();
            try
            {
                
                cmd = "select UserID from User1 where Role = 'Lecturer'";
                sqlconfig.singleResult(cmd);
                comboBoxLecturerID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxLecturerID.DisplayMemberPath = "UserID";

                cmd1 = "select SubjectID from Subject";
                sqlconfig.singleResult(cmd1);
                comboBoxSubjectID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxSubjectID.DisplayMemberPath = "SubjectID";

                comboBoxStartTime.Items.Add("09:00");
                comboBoxStartTime.Items.Add("10:00");
                comboBoxStartTime.Items.Add("11:00");
                comboBoxStartTime.Items.Add("12:00");
                comboBoxStartTime.Items.Add("13:00");
                comboBoxStartTime.Items.Add("14:00");
                comboBoxStartTime.Items.Add("15:00");
                comboBoxStartTime.Items.Add("16:00");
                comboBoxStartTime.Items.Add("17:00");
                comboBoxStartTime.Items.Add("18:00");

                comboBoxEndTime.Items.Add("09:00");
                comboBoxEndTime.Items.Add("10:00");
                comboBoxEndTime.Items.Add("11:00");
                comboBoxEndTime.Items.Add("12:00");
                comboBoxEndTime.Items.Add("13:00");
                comboBoxEndTime.Items.Add("14:00");
                comboBoxEndTime.Items.Add("15:00");
                comboBoxEndTime.Items.Add("16:00");
                comboBoxEndTime.Items.Add("17:00");
                comboBoxEndTime.Items.Add("18:00");


                comboBoxDate.Items.Add("Monday");
                comboBoxDate.Items.Add("Tuesday");
                comboBoxDate.Items.Add("Wednesday");
                comboBoxDate.Items.Add("Thursday");
                comboBoxDate.Items.Add("Friday");
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int Timetable;

            Timetable = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(Timetable) as DataRowView;

            MainID = Row1["ID"].ToString().Trim();
            //MessageBox.Show(MainID);
            comboBoxSubjectID.Text = Row1["SubjectID"].ToString().Trim();
            comboBoxLecturerID.Text = Row1["LecturerID"].ToString().Trim();
            comboBoxDate.Text = Row1["Days"].ToString().Trim();
            datePickerStartDate.Text = Row1["DateFrom"].ToString().Trim();
            datePickerEndDate.Text = Row1["DateTo"].ToString().Trim();
            comboBoxStartTime.Text = Row1["StartTime"].ToString().Trim();
            comboBoxEndTime.Text = Row1["EndTime"].ToString().Trim();

        }

        private void ClearText()
        {
            comboBoxSubjectID.Text = "";
            comboBoxLecturerID.Text = "";
            comboBoxDate.Text = "";
            datePickerStartDate.Text = "";
            datePickerEndDate.Text = "";
            comboBoxStartTime.Text = "";
            comboBoxEndTime.Text = "";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string getID;
            string date1 = datePickerStartDate.SelectedDate.Value.ToString("yyyy-MM-dd");
            string date2 = datePickerEndDate.SelectedDate.Value.ToString("yyyy-MM-dd");

            try
            {
                cmd = "INSERT INTO Timetable(SubjectID, LecturerID, Days, DateFrom, DateTo, StartTime, EndTime) Values('" + comboBoxSubjectID.Text + "','" + comboBoxLecturerID.Text.Trim() + "','" + comboBoxDate.Text + "','" + date1 + "','"+ date2 + "','" + comboBoxStartTime.Text + "','" + comboBoxEndTime.Text + "')";
                sqlconfig.Execute_Query(cmd);

                cmd1 = "select TOP 1 ID from TimeTable ORDER BY ID DESC";
                sqlconfig.singleResult(cmd1);
                getID = sqlconfig.dt.Rows[0][0].ToString();


                var from = DateTime.Parse(datePickerStartDate.SelectedDate.Value.ToShortDateString());
                var to = DateTime.Parse(datePickerEndDate.SelectedDate.Value.ToShortDateString());
                List<String> allDate = from.GetWeekdayInRange(to,DayOfWeek.Monday);
                if (comboBoxDate.Text == "Monday") 
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Monday);
                } 
                else if (comboBoxDate.Text == "Tuesday")
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Tuesday);
                }
                else if (comboBoxDate.Text == "Wednesday")
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Wednesday);
                }
                else if (comboBoxDate.Text == "Thursday")
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Thursday);
                }
                else if (comboBoxDate.Text == "Friday")
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Friday);
                }
                else if (comboBoxDate.Text == "Saturday")
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Saturday);
                }
                else if (comboBoxDate.Text == "Sunday")
                {
                    allDate = from.GetWeekdayInRange(to, DayOfWeek.Sunday);
                }

                allDate.RemoveAt(allDate.Count - 1);
               /* var datelist = string.Join(Environment.NewLine, allDate);
                MessageBox.Show(datelist);*/
                foreach (string getweekday in allDate)
                {
                    cmd2 = "INSERT INTO TimetableDtl(MainID, Days, SubjectID, LecturerID,  StartTime, EndTime) Values('" + getID + "','" + getweekday + "','" + comboBoxSubjectID.Text + "','" + comboBoxLecturerID.Text + "','" + comboBoxStartTime.Text + "','" + comboBoxEndTime.Text + "')";
                    sqlconfig.Execute_Query(cmd2);
                }
                
                

                MessageBox.Show("Done Create!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                cmd = "DELETE FROM Timetable WHERE ID='" + MainID + "'";
                sqlconfig.Execute_Query(cmd);

                cmd1 = "DELETE FROM TimetableDtl WHERE MainID='" + MainID + "'";
                sqlconfig.Execute_Query(cmd1);

                MessageBox.Show("Done Delete!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

            /* try
            {
                cmd = "UPDATE StudentInformation SET StudentName ='" + textBoxName.Text + "',IC='" + textBoxIC.Text + "',YearEnroll='" + textBoxYearEnroll.Text + "',CourseID='" + textBoxCourseID.Text + "',CardID='" + textBoxCardID.Text + "' WHERE StudentID='" + textBoxStudentID.Text + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Modify!");
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/

        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            comboBoxSubjectID.Text = "";
            comboBoxLecturerID.Text = "";
            comboBoxDate.Text = "";
            datePickerStartDate.Text = "";
            datePickerEndDate.Text = "";
            comboBoxStartTime.Text = "";
            comboBoxEndTime.Text = "";
        }
    }
}
