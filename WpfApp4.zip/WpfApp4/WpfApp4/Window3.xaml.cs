﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd, userID1;
        public Window3()
        {
            InitializeComponent();
        }

        private void window3loaded(object sender, RoutedEventArgs e)
        {
            getgrid();
            //listView.ItemsSource = dt.DefaultView;
        }

        private void window3closing(object sender, CancelEventArgs e)
        {
            Window2 win2 = new Window2();
            //this.Close();
            win2.Show();
        }

        private void getgrid()
        {
            try
            {
                
                cmd = "select * from User1";
                sqlconfig.singleResult(cmd);
                
                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }


        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int User1;

            User1 = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(User1) as DataRowView;
            userID1 = Row1["UserID"].ToString().Trim();
            textBox.Text = userID1;
            textBox1.Text = Row1["Password"].ToString().Trim();
            textBox2.Text = Row1["Role"].ToString().Trim();

        }
        private void ClearText()
        {
            textBox.Text = null;
            textBox1.Text = null;
            textBox2.Text = null;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                cmd = "INSERT INTO User1(UserID,Password,Role) Values('" + textBox.Text + "','" + textBox1.Text + "','" + textBox2.Text + "')";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Create!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Duplicate UserID");
            }
            

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
           
            try 
            {
                cmd = "DELETE FROM User1 WHERE UserID='" + textBox.Text + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Delete!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                if (textBox.Text.ToString().Trim() == userID1)
                {
                    cmd = "UPDATE User1 SET Password='" + textBox1.Text + "',Role='" + textBox2.Text + "' WHERE UserID='" + textBox.Text + "'";
                    sqlconfig.Execute_Query(cmd);
                    MessageBox.Show("Done Modify!");
                    getgrid();
                } else
                {
                    MessageBox.Show("Could not modify User ID.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            textBox.Text = null;
            textBox1.Text = null;
            textBox2.Text = null;
        }
    }
}
