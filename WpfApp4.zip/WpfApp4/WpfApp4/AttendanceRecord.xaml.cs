﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.ComponentModel;
using System.IO;
using Microsoft.Win32;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for AttendanceRecord.xaml
    /// </summary>
    public static class CSVUtlity
    {
        public static void ToCSV(this DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }
    }
    public partial class AttendanceRecord : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd, cmd1, cmd2, MainID, lecturercode,filename;
        public AttendanceRecord(string lecturer)
        {
            lecturercode = lecturer;
            InitializeComponent();
        }

        private void AttendanceRecordloaded(object sender, RoutedEventArgs e)
        {
            getgrid();
            getcomboboxdata();
        }

        private void AttendanceRecordclosing(object sender, CancelEventArgs e)
        {
            LecturerPage LecturerPage1 = new LecturerPage(lecturercode);
            LecturerPage1.Show();
        }

        

    private void getgrid()
        {
            try
            {

                cmd = "select A.AttendanceID, A.StudentID, B.StudentName, A.SubjectID, A.CheckInTime, A.CheckOutTime, A.Date1 from AttendanceRecord A INNER JOIN StudentInformation B ON A.StudentID = B.StudentID";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void getcomboboxdata()
        {
            ComboBox time1 = new ComboBox();
            try
            {

                cmd = "select DISTINCT SubjectID from TimetableDTL WHERE LecturerID='" + lecturercode + "'";
                sqlconfig.singleResult(cmd);
                comboBoxSubjectID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxSubjectID.DisplayMemberPath = "SubjectID";

                cmd1 = "select DISTINCT B.StudentID from Enrollment B inner join TimetableDTL A ON A.SubjectID = B.SubjectID where A.LecturerID='" + lecturercode + "'";
                sqlconfig.singleResult(cmd1);
                comboBoxStudentID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxStudentID.DisplayMemberPath = "StudentID";


            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int Timetable;

            Timetable = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(Timetable) as DataRowView;

            MainID = Row1["AttendanceID"].ToString().Trim();
            //MessageBox.Show(MainID);
            comboBoxSubjectID.Text = Row1["SubjectID"].ToString().Trim();
            comboBoxStudentID.Text = Row1["StudentID"].ToString().Trim();
            comboBoxDate.Text = Row1["Date1"].ToString().Trim();
            datePickerCheckInTime.Text = Row1["CheckInTime"].ToString().Trim();
            datePickerCheckOutTime.Text = Row1["CheckOutTime"].ToString().Trim();

        }
        private void getSubjecttime(string SubjectCode1)
        {
            try
            {
                cmd1 = "select Days from TimetableDTL WHERE LecturerID='" + lecturercode + "' AND SubjectID='" + SubjectCode1 + "'";
                sqlconfig.singleResult(cmd1);
                comboBoxDate.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxDate.DisplayMemberPath = "Days";

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                cmd = "DELETE FROM AttendanceRecord WHERE AttendanceID='" + MainID + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Delete!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            comboBoxSubjectID.Text = "";
            comboBoxStudentID.Text = "";
            comboBoxDate.Text = "";
            datePickerCheckInTime.Text = "";
            datePickerCheckOutTime.Text = "";
            MainID = "";
        }

        private void ClearText()
        {
            comboBoxSubjectID.Text = "";
            comboBoxStudentID.Text = "";
            comboBoxDate.Text = "";
            datePickerCheckInTime.Text = "";
            datePickerCheckOutTime.Text = "";
            MainID = "";
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            string date1 = datePickerCheckInTime.SelectedDate.Value.ToString("yyyy-MM-dd");
            string date2 = datePickerCheckOutTime.SelectedDate.Value.ToString("yyyy-MM-dd");
            try
            {
                cmd = "UPDATE AttendanceRecord SET CheckInTime ='" + date1 + "',CheckOutTime='" + date2 + "',Date1='" + comboBoxDate.Text + "' WHERE AttendanceID = '" + MainID + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Modify!");
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void getStudentName(string studentname1)
        {
            try
            {
                cmd1 = "select StudentName from StudentInformation WHERE StudentID='" + studentname1 + "'";
                sqlconfig.singleResult(cmd1);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            
            getgrid();
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV file (*.CSV)|*.CSV";
            if (saveFileDialog.ShowDialog() == true)
            {
                String filename = saveFileDialog.FileName;
                sqlconfig.dt.ToCSV(filename);
                MessageBox.Show("Done Export.");
            }
                
        }

        private void dropdownClosed(object sender, EventArgs e)
        {
            string subject1 = comboBoxSubjectID.Text;
            getSubjecttime(subject1);
        }
        private void dropdown1Closed(object sender, EventArgs e)
        {
            string studentname1 = comboBoxSubjectID.Text;
            getStudentName(studentname1);
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string date1 = datePickerCheckInTime.SelectedDate.Value.ToString("yyyy-MM-dd");
            string date2 = datePickerCheckOutTime.SelectedDate.Value.ToString("yyyy-MM-dd");
            try
            {
                cmd = "INSERT INTO Timetable(SubjectID, StudentID, Date1, CheckInTime, CheckOutTime) Values('" + comboBoxSubjectID.Text + "','" + comboBoxStudentID.Text + "','" + comboBoxDate.Text + "','" + date1 + "','" + date2 + "')";
                sqlconfig.Execute_Query(cmd);


                MessageBox.Show("Done Create!");
                ClearText();
                getgrid();
            }
            catch
            {
                //MessageBox.Show(ex.Message);
            }

        }
    }
}
