﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace WpfApp4
{

    public class SqlConfiguration
    {
        SqlCommand cmd;
        public SqlDataReader dataReader;
        SqlDataAdapter sda;
        public DataTable dt;
        int result;
        public static string connectionString = @"Data Source=DESKTOP-49TRT0K\SQLEXPRESS;Initial Catalog=AttendanceSystem;Integrated Security=True";   
        public SqlConnection con = new SqlConnection(connectionString);

        public void Execute_Query(string sql)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery();

                //MessageBox.Show("Complete");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        public void singleResult(string sql)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand();
                sda = new SqlDataAdapter();
                dt = new DataTable();

                cmd.Connection = con;
                cmd.CommandText = sql;
                sda.SelectCommand = cmd;
                sda.Fill(dt);
             
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

    }
    
}
