﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for Subject.xaml
    /// </summary>
    
    public partial class Subject : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd, getsubject;
        public Subject()
        {
            InitializeComponent();
        }
        private void subjectloaded(object sender, RoutedEventArgs e)
        {
            getgrid();
        }

        private void subjectclosing(object sender, CancelEventArgs e)
        {
            Window2 win2 = new Window2();
            win2.Show();
        }
        private void getgrid()
        {
            try
            {

                cmd = "select * from Subject";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int Subject1;

            Subject1 = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(Subject1) as DataRowView;
            getsubject = Row1["SubjectID"].ToString().Trim();
            textBoxSubjectID.Text = getsubject;
            textBoxSubjectName.Text = Row1["SubjectName"].ToString().Trim();

        }

        private void ClearText()
        {
            textBoxSubjectID.Text = null;
            textBoxSubjectName.Text = null;
        }
        private void button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                cmd = "INSERT INTO Subject(SubjectID, SubjectName) Values('" + textBoxSubjectID.Text + "','" + textBoxSubjectName.Text + "')";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Create!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Duplicate Subject ID");
            }


        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                cmd = "DELETE FROM Subject WHERE SubjectID='" + textBoxSubjectID.Text + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Delete!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void button2_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if  (textBoxSubjectID.Text.ToString().Trim() == getsubject) 
                {
                    cmd = "UPDATE Subject SET SubjectName ='" + textBoxSubjectName.Text + "' WHERE SubjectID = '" + textBoxSubjectID.Text + "'";
                    sqlconfig.Execute_Query(cmd);
                    MessageBox.Show("Done Modify!");
                    getgrid();
                }
                else
                {
                    MessageBox.Show("Could not modify Subject ID.");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            textBoxSubjectID.Text = null;
            textBoxSubjectName.Text = null;
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            Window2 win2 = new Window2();
            this.Close();
            win2.Show();
        }
    }
}
