﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        string connetionString;
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader dataReader;

        public Window1()
        {
            InitializeComponent();
            connetionString = @"Data Source=DESKTOP-49TRT0K\SQLEXPRESS;Initial Catalog=AttendanceSystem;Integrated Security=True";
            conn = new SqlConnection(connetionString);
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            conn.Open();
            try
            {
                cmd = new SqlCommand("select Role from User1 where UserID='" + textBox.Text + "' AND password='" + textBox1.Password + "'", conn);
                dataReader = cmd.ExecuteReader();

                if (dataReader.Read())
                {
                    string userRole = dataReader.GetString(0).Trim().ToUpper();
                    string userCode = textBox.Text.ToUpper();

                    if (userRole == "ADMINISTRATOR")
                    {
                        Window2 win2 = new Window2();
                        this.Close();
                        win2.Show();
                    } else if (userRole == "LECTURER")
                    {
                        LecturerPage LecturerPage1 = new LecturerPage(userCode);
                        this.Close();
                        LecturerPage1.Show();
                    }
                    
                }
                else
                {
                    MessageBox.Show("Incorrect UserID or Password");
                }
                
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            conn.Close();

        }
    }
}
