﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for Enrollment.xaml
    /// </summary>
    public partial class Enrollment : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd, cmd1, cmd2, MainID;
        public Enrollment()
        {
            InitializeComponent();
        }

        private void Enrollmentloaded(object sender, RoutedEventArgs e)
        {
            getgrid();
            getcomboboxdata();
        }

        private void Enrollmentclosing(object sender, CancelEventArgs e)
        {
            Window2 win2 = new Window2();
            win2.Show();
        }

        private void getgrid()
        {
            try
            {

                cmd = "select * from Enrollment";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }
        private void getcomboboxdata()
        {
            ComboBox time1 = new ComboBox();
            try
            {

                cmd = "select StudentID from StudentInformation";
                sqlconfig.singleResult(cmd);
                comboBoxStudentID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxStudentID.DisplayMemberPath = "StudentID";

                cmd1 = "select SubjectID from Subject";
                sqlconfig.singleResult(cmd1);
                comboBoxSubjectID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxSubjectID.DisplayMemberPath = "SubjectID";

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView Row1;
            int Timetable;

            Timetable = listView.SelectedIndex;
            Row1 = listView.Items.GetItemAt(Timetable) as DataRowView;

            MainID = Row1["EnrollID"].ToString().Trim();
            //MessageBox.Show(MainID);
            comboBoxSubjectID.Text = Row1["SubjectID"].ToString().Trim();
            comboBoxStudentID.Text = Row1["StudentID"].ToString().Trim();
            datePickerStartDate.Text = Row1["DateFrom"].ToString().Trim();
            datePickerEndDate.Text = Row1["DateTo"].ToString().Trim();

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string date1 = datePickerStartDate.SelectedDate.Value.ToString("yyyy-MM-dd");
            string date2 = datePickerEndDate.SelectedDate.Value.ToString("yyyy-MM-dd");

            try
            {
                if (datePickerEndDate.SelectedDate < datePickerStartDate.SelectedDate) {
                    MessageBox.Show("End Date earlier than Start Date.");
                } else
                {
                    cmd = "INSERT INTO Enrollment(StudentID, SubjectID, DateFrom, DateTo) Values('" + comboBoxStudentID.Text + "','" + comboBoxSubjectID.Text.Trim() + "','" + date1 + "','" + date2 + "')";
                    sqlconfig.Execute_Query(cmd);


                    MessageBox.Show("Done Create!");
                    ClearText();
                    getgrid();
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                cmd = "DELETE FROM Enrollment WHERE EnrollID='" + MainID + "'";
                sqlconfig.Execute_Query(cmd);
                MessageBox.Show("Done Delete!");
                ClearText();
                getgrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            string date1 = datePickerStartDate.SelectedDate.Value.ToString("yyyy-MM-dd");
            string date2 = datePickerEndDate.SelectedDate.Value.ToString("yyyy-MM-dd");
            

            try
            {
                if (datePickerEndDate.SelectedDate < datePickerStartDate.SelectedDate)
                {
                    MessageBox.Show("End Date earlier than Start Date.");
                }
                else
                {
                    cmd = "UPDATE Enrollment SET StudentID ='" + comboBoxStudentID.Text + "',SubjectID='" + comboBoxSubjectID.Text + "',DateFrom='" + date1 + "',DateTo='" + date2 + "' WHERE EnrollID='" + MainID + "'";
                    sqlconfig.Execute_Query(cmd);
                    MessageBox.Show("Done Modify!");
                    ClearText();
                    getgrid();
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void ClearText()
        {
            comboBoxSubjectID.Text = "";
            comboBoxStudentID.Text = "";
            datePickerStartDate.Text = "";
            datePickerEndDate.Text = "";
        }
        private void button3_Click(object sender, RoutedEventArgs e)
        {
            comboBoxSubjectID.Text = "";
            comboBoxStudentID.Text = "";
            datePickerStartDate.Text = "";
            datePickerEndDate.Text = "";
        }

    }
}
