﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Threading;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for ClassSession.xaml
    /// </summary>
    public partial class ClassSession : Window
    {
        int retCode;
        int hCard;
        int hContext;
        int Protocol;
        public bool connActive = false;
        string readername = "ACS ACR122 0";      // change depending on reader
        public byte[] SendBuff = new byte[263];
        public byte[] RecvBuff = new byte[263];
        public int SendLen, RecvLen, nBytesRet, reqType, Aprotocol, dwProtocol, cbPciLength;
        public Card.SCARD_READERSTATE RdrState;
        public Card.SCARD_IO_REQUEST pioSendRequest;

        internal enum SmartcardState
        {
            None = 0,
            Inserted = 1,
            Ejected = 2
        }


        private BackgroundWorker _worker;
        private Card.SCARD_READERSTATE[] states;

        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd, cmd1, lecturercode;

        int Zero;

        public void SelectDevice()
        {
            List<string> availableReaders = ListReaders();
            if (availableReaders.Count == 0) { return; }

            this.RdrState = new Card.SCARD_READERSTATE();
            readername = availableReaders[0].ToString();//selecting first device
            this.RdrState.RdrName = readername;

            ///
            states = new Card.SCARD_READERSTATE[1];
            states[0] = new Card.SCARD_READERSTATE();
            states[0].RdrName = readername;
            states[0].UserData = Zero;
            states[0].RdrCurrState = Card.SCARD_STATE_EMPTY;
            states[0].RdrEventState = 0;
            states[0].ATRLength = 0;
            states[0].ATRValue = null;


            if (availableReaders.Count > 0)
            {
                this._worker = new BackgroundWorker();
                this._worker.WorkerSupportsCancellation = true;
                this._worker.DoWork += WaitChangeStatus;
                this._worker.RunWorkerAsync();
            }
        }

        private void WaitChangeStatus(object sender, DoWorkEventArgs e)
        {
            while (!e.Cancel)
            {
                int nErrCode = Card.SCardGetStatusChange(hContext, 1000, ref states[0], 1);

                //Check if the state changed from the last time.
                if ((this.states[0].RdrEventState & 2) == 2)
                {
                    //Check what changed.
                    SmartcardState state = SmartcardState.None;
                    if ((this.states[0].RdrEventState & 32) == 32 && (this.states[0].RdrCurrState & 32) != 32)
                    {
                        //The card was inserted.
                        state = SmartcardState.Inserted;
                    }
                    else if ((this.states[0].RdrEventState & 16) == 16 && (this.states[0].RdrCurrState & 16) != 16)
                    {
                        //The card was ejected.
                        state = SmartcardState.Ejected;
                    }
                    if (state != SmartcardState.None && this.states[0].RdrCurrState != 0)
                    {
                        switch (state)
                        {
                            case SmartcardState.Inserted:
                                {
                                    if (connectCard())
                                    {
                                        string cardUID = getcardUID();
                                        Dispatcher.BeginInvoke(new Action(delegate ()
                                        {
                                            //listBox.Items.Add(cardUID);
                                            try
                                            {
                                                if (button1.Content.ToString() == "Stop")
                                                {
                                                    //MessageBox.Show(cardUID);
                                                    cmd1 = "select A.StudentID from StudentInformation A INNER JOIN Enrollment B ON A.StudentID = B.StudentID WHERE A.CardID='" + cardUID + "' AND B.SubjectID = '" + comboBoxSubjectID.Text + "'";
                                                    sqlconfig.singleResult(cmd1);
                                                    if (listBox.Items.Count == 0)
                                                    {
                                                        listBox.Items.Add(sqlconfig.dt.Rows[0][0]);
                                                    }
                                                    else
                                                    {
                                                        foreach (string StudentName1 in listBox.Items)
                                                        {
                                                            if (sqlconfig.dt.Rows[0][0].ToString() == StudentName1)
                                                            {
                                                                MessageBox.Show("This Student is already check in / check out.");
                                                            }
                                                            else
                                                            {
                                                                listBox.Items.Add(sqlconfig.dt.Rows[0][0]);
                                                            }

                                                        }
                                                    }
                                                }
                                                

                                            }
                                            catch (Exception ex)
                                            {
                                                // MessageBox.Show(ex.Message);
                                                MessageBox.Show("This student is not enroll for this subject or invalid cardID.");
                                            }
                                        }));
                                        //MessageBox.Show(cardUID); //displaying on text block
                                    }
                                    break;
                                }
                            case SmartcardState.Ejected:
                                {
                                    //MessageBox.Show("Card ejected");
                                    break;
                                }
                            default:
                                {
                                    //MessageBox.Show("Some other state ...");
                                    break;
                                }
                        }
                    }
                    //Update the current state for the next time they are checked.
                    this.states[0].RdrCurrState = this.states[0].RdrEventState;
                }
            }
        }

        public bool connectCard()
        {
            connActive = true;

            retCode = Card.SCardConnect(hContext, readername, Card.SCARD_SHARE_SHARED,
            Card.SCARD_PROTOCOL_T0 | Card.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != Card.SCARD_S_SUCCESS)
            {
                //MessageBox.Show(Card.GetScardErrMsg(retCode), "Card not available", MessageBoxButton.OK, MessageBoxImage.Error);
                connActive = false;
                return false;
            }
            return true;
        }

        private string getcardUID()//only for mifare 1k cards
        {
            string cardUID = "";
            byte[] receivedUID = new byte[256];
            Card.SCARD_IO_REQUEST request = new Card.SCARD_IO_REQUEST();
            request.dwProtocol = Card.SCARD_PROTOCOL_T1;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(Card.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command for Mifare cards
            int outBytes = receivedUID.Length;
            int status = Card.SCardTransmit(hCard, ref request, ref sendBytes[0], sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            if (status != Card.SCARD_S_SUCCESS)
            {
                cardUID = "Error";
            }
            else
            {
                cardUID = BitConverter.ToString(receivedUID.Take(4).ToArray()).Replace("-", string.Empty).ToLower();
            }

            return cardUID;
        }

        public List<string> ListReaders()
        {
            int ReaderCount = 0;
            List<string> AvailableReaderList = new List<string>();

            //Make sure a context has been established before 
            //retrieving the list of smartcard readers.
            retCode = Card.SCardListReaders(hContext, null, null, ref ReaderCount);
            if (retCode != Card.SCARD_S_SUCCESS)
            {
                MessageBox.Show(Card.GetScardErrMsg(retCode));
                //connActive = false;
            }

            byte[] ReadersList = new byte[ReaderCount];

            //Get the list of reader present again but this time add sReaderGroup, retData as 2rd & 3rd parameter respectively.
            retCode = Card.SCardListReaders(hContext, null, ReadersList, ref ReaderCount);
            if (retCode != Card.SCARD_S_SUCCESS)
            {
                MessageBox.Show(Card.GetScardErrMsg(retCode));
            }

            string rName = "";
            int indx = 0;
            if (ReaderCount > 0)
            {
                // Convert reader buffer to string
                while (ReadersList[indx] != 0)
                {

                    while (ReadersList[indx] != 0)
                    {
                        rName = rName + (char)ReadersList[indx];
                        indx = indx + 1;
                    }

                    //Add reader name to list
                    AvailableReaderList.Add(rName);
                    rName = "";
                    indx = indx + 1;

                }
            }
            return AvailableReaderList;

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            if (button1.Content.ToString() == "Stop")
            {
                MessageBox.Show("Please stop scanning.");
            }
            else
            {
                foreach (string StudentID1 in listBox.Items)
                {
                    try
                    {
                        cmd = "INSERT INTO AttendanceRecord(StudentID,SubjectID,Date1,CheckInTime) Values('" + StudentID1 + "','" + comboBoxSubjectID.Text + "','" + comboBoxDay.Text + "',GETDATE())";
                        sqlconfig.Execute_Query(cmd);
                        MessageBox.Show("Done Check In!");

                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show("Duplicate UserID");
                    }
                }
                listBox.Items.Clear();
            }
        
            
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            if (button1.Content.ToString() == "Stop")
            {
                MessageBox.Show("Please stop scanning.");
            }
            else
            {
                foreach (string StudentID1 in listBox.Items)
                {
                    try
                    {
                        cmd = "UPDATE AttendanceRecord SET CheckOutTime=GETDATE() WHERE StudentID='" + StudentID1 + "' AND SubjectID = '" + comboBoxSubjectID.Text + "' AND CONVERT(date, CheckInTime) = CONVERT(date, getdate())";
                        sqlconfig.Execute_Query(cmd);
                        MessageBox.Show("Done Check Out!");

                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show("Duplicate UserID");
                    }
                }
                listBox.Items.Clear();
            }
                
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            SubjectStudentList SubjectStudentList1 = new SubjectStudentList(comboBoxSubjectID.Text);
            SubjectStudentList1.Show();
        }

        internal void establishContext()
        {
            retCode = Card.SCardEstablishContext(Card.SCARD_SCOPE_SYSTEM, 0, 0, ref hContext);
            if (retCode != Card.SCARD_S_SUCCESS)
            {
                MessageBox.Show("Check your device and please restart again", "Reader not connected", MessageBoxButton.OK, MessageBoxImage.Warning);
                connActive = false;
                return;
            }
        }

        public ClassSession(string lecturer)
        {
            lecturercode = lecturer;
            InitializeComponent();
            SelectDevice();
            establishContext();


        }

        private void ClassSessionloaded(object sender, RoutedEventArgs e)
        {
            getcomboboxdata();
        }

        private void ClassSessionclosing(object sender, CancelEventArgs e)
        {
            LecturerPage LecturerPage1 = new LecturerPage(lecturercode);
            LecturerPage1.Show();
        }

        private void getcomboboxdata()
        {
            ComboBox time1 = new ComboBox();
            try
            {

                cmd1 = "select DISTINCT SubjectID from TimetableDTL WHERE LecturerID='" + lecturercode + "'";
                sqlconfig.singleResult(cmd1);
                comboBoxSubjectID.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxSubjectID.DisplayMemberPath = "SubjectID";

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void getSubjecttime(string SubjectCode1)
        {
            try
            {
                cmd1 = "select Days from TimetableDTL WHERE LecturerID='" + lecturercode + "' AND SubjectID='" + comboBoxSubjectID.Text + "'";
                sqlconfig.singleResult(cmd1);
                comboBoxDay.ItemsSource = sqlconfig.dt.DefaultView;
                comboBoxDay.DisplayMemberPath = "Days";

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

        private void dropdownClosed(object sender, EventArgs e)
        {
            string SubjectCode1 = comboBoxSubjectID.Text;
            getSubjecttime(SubjectCode1);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if ((comboBoxSubjectID.Text == "") && (comboBoxDay.Text == "")) {
                MessageBox.Show("Please select course and date.");
            }
            else
            {
                if (button1.Content.ToString() == "Stop")
                {
                    button1.Content = "Scan";
                }
                else
                {
                    button1.Content = "Stop";
                }
            }

        }
    }
}
