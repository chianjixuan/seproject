﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for SubjectStudentList.xaml
    /// </summary>
    public partial class SubjectStudentList : Window
    {
        SqlConfiguration sqlconfig = new SqlConfiguration();
        string cmd,subjectcode;
        public SubjectStudentList(string subject)
        {
            subjectcode = subject;
            InitializeComponent();
            getgrid();
        }
        private void getgrid()
        {
            try
            {

                cmd = "select A.StudentID, D.StudentName, A.SubjectID, (((SELECT COUNT(*) FROM AttendanceRecord C WHERE (A.StudentID = C.StudentID AND A.SubjectID = C.SubjectID)) * 100 )/ (SELECT COUNT(*) FROM Timetabledtl B WHERE B.SubjectID = A.SubjectID AND CONVERT(date, Days) < CONVERT(date, getdate())) ) AS Percentage1 FROM Enrollment A INNER JOIN StudentInformation D ON A.StudentID = D.StudentID WHERE A.SubjectID = '" + subjectcode + "'";
                sqlconfig.singleResult(cmd);

                listView.ItemsSource = sqlconfig.dt.DefaultView;

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

        }

    }
}
